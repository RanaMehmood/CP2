<?php
echo "start1";
$target_dir = "songs_photos/";
$target_file = $target_dir . basename($_FILES["song_photo"]["name"]);

$target_dir2 = "songs_audio/";
$target_file2 = $target_dir2 . basename($_FILES["song_audio"]["name"]);

$uploadOk = 1;
$uploadOk2 = 1;

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$target_file = $target_dir . "photo-".time().".".$imageFileType;

$audioFileType = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
$target_file2 = $target_dir2 . "audio-".time().".".$audioFileType;
echo "start2";
//if(isset($_POST['submit']))
    {
echo "start3";
$path = "songs_audio/"; //file to place within the server
$valid_formats1 = array("mp3", "ogg", "flac"); //list of file extention to be accepted
//if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {
		echo "start4";
        $file1 = $_FILES['song_audio']['name']; //input file name in this code is file1
        $size = $_FILES['song_audio']['size'];

        if(strlen($file1))
            {
                list($txt, $ext) = explode(".", $file1);
                if(in_array($ext,$valid_formats1))
                {
                        $actual_image_name = $txt.".".$ext;
                        $tmp = $_FILES['song_audio']['tmp_name'];
                        if(move_uploaded_file($tmp, $target_file2))
                            {
                            echo "success====";
                            }
                        else
                            echo "failed";              
                    }
        }
    }
}

?>



