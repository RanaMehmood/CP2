
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAD-H UCP Assignment 2</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<meta charset="UTF-8">
	<meta name="description" content="UCP Section H Assignment 2">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="M Talha">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="images/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="js/main.js"></script> 
</head>
<body>

	
<?php
include "session.php";
?>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container bar">
		<div class="row">
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			<li class="nav-item">
				<h2 style="color:orange" style="width:100px">SOUNDCLOUD</h2>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="home.php"><h5>Home</h5></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="#"><h5>Stream</h5></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="#"><h5>Collection</h5></a>
			  </li>   
			<li>  
			<div class="container">
					     <div class="row">    
        <div class="col-xs-10 col-xs-offset-2">
		    <div class="input-group" >        
                <input type="text" class="form-control" style="width:700px" name="x" placeholder="Search term...">
                
            </div>
        </div>
	</div>
</div>
        </li>
		<li class="nav-item">
				<a class="nav-link active" href="login.php"><span style="width:125px"><h5>login</h5></span></a>
			  </li>
             <li class="nav-item">
				<a class="nav-link active" href="create.php"><span style="color:orange" style="width:100px"><h5>create</h5></span></a>
			  </li>			  
			</ul>
			</div>
		</div>
	</div>
	
</nav>
<div class="container main">
  <div class="row">
    <div class="col-sm-4">
      
  </div>
  <div class="col-sm-4" style="border:1px solid #ccc; padding-top:125px; padding-bottom:125px">
  <div class="row">
  <div class="col-sm-12">
      
	  <form name="RegForm" action="check.php" onsubmit="formvalidatefunc()" method="post">
	 
	 <p style="color:black" >------------------------login------------------------</p>
	 
	  <input type="text" class="ibt-2" name="email" placeholder="your eamil address or profile url">
	  
	  </br>
	  <input type="password" class="ibt-2" name="pass" placeholder="password yahoo">
	  
	  </br>
	  <p>
	  <span style="color:red">invalid your password or eamil address</span>
	  </br>
	  <span style="color:red">Plz enter correct password and eamil address</span>
	  </br>
	  <button type="submit" class="ibt-3" >countinue</button>
	  </form>
  </div>
  </div>
  </div>
  <div class="col-sm-4" >
      
  </div>
</div>
</div>


</body>
</html>
