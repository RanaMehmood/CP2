<?php

//echo "everthing is ok";
//
$song_id = $_POST['song_id'];
$song_name = $_POST['song_name'];
$song_album = $_POST['song_album'];

$target_dir = "songs_photos/";
$target_file = $target_dir . basename($_FILES["song_photo"]["name"]);

$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$target_file = $target_dir . "photo-".time().".".$imageFileType;

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["song_photo"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["song_photo"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
/*if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["song_photo"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["song_photo"]["name"]). " has been uploaded.";
    } 
	else {
        echo "Sorry, there was an error uploading your file.";
    }
	
}*/
if($uploadOk==1){
$target_dir2 = "songs_audio/";
$target_file2 = $target_dir2 . basename($_FILES["song_audio"]["name"]);
$audioFileType = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
$target_file2 = $target_dir2 . "audio-".time().".".$audioFileType;

$path = "songs_audio/"; //file to place within the server
$valid_formats1 = array("mp3", "ogg", "flac"); //list of file extention to be accepted
//if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {
		
        $file1 = $_FILES['song_audio']['name']; //input file name in this code is file1
        $size = $_FILES['song_audio']['size'];

        if(strlen($file1))
            {
                list($txt, $ext) = explode(".", $file1);
                if(in_array($ext,$valid_formats1))
                {
                        $actual_image_name = $txt.".".$ext;
                        $tmp = $_FILES['song_audio']['tmp_name'];
                        if(move_uploaded_file($tmp, $target_file2))
                            {
								$uploadOk=1;
								require_once("conn.php");
								$query2="INSERT INTO `song`(`id`, `photo_path`, `Name`, `audio_file_path`, `album_name`) VALUES ('$song_id','$target_file','$song_name','$target_file2','$song_album')";
				$res2 = mysqli_query($conn,"$query2") or die("Query error". mysql_error());
				header("Location: songAlbum.php");
                            
							
                            }
                        else
						{
                            echo "failed";
						$uploadOk=0;}						
                    }
			}
    }
	
		
				

	}

?>