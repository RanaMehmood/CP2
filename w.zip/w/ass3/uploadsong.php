
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAD-H UCP Assignment 2</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<meta charset="UTF-8">
	<meta name="description" content="UCP Section H Assignment 2">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="M Talha">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="images/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="js/main.js"></script> 
</head>
<body>

	<?php
include "session.php";

echo $_SESSION["id"];
?>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container bar">
		<div class="row">
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			<li class="nav-item">
				<h2 style="color:orange" style="width:100px">SOUNDCLOUD</h2>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="home.php"><h5>Home</h5></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="Homecreate.php"><h5>upload-album</h5></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link active" style="width:100px" href="uploadsong.php"><h5>upload-song</h5></a>
			  </li>   
			<li>  
			<div class="container">
					     <div class="row">    
        <div class="col-xs-10 col-xs-offset-2">
		    <div class="input-group" >        
                <input type="text" class="form-control" style="width:700px" name="x" placeholder="Search term...">
                
            </div>
        </div>
	</div>
</div>
        </li>
		<li class="nav-item">
				<a class="nav-link active" href="logout.php"><span style="width:125px"><h5>logout</h5></span></a>
			  </li>
             <li class="nav-item">
				<a class="nav-link active" href="create.php"><span style="color:orange" style="width:100px"><h5>create</h5></span></a>
			  </li>			  
			</ul>
			</div>
		</div>
	</div>
	
</nav>

</br>
</br>
<h1>       WELCOME	TO 	LOGIN	HOME	PAGE 	<span style = "color:red;"><?php

echo $_SESSION["id"];
?></span></h1>
</br>
<h1><span style = "color:orange;">
<div class="container sub">
  <form action="songAlbum.php" method="post" enctype="multipart/form-data">
  <div class="row">
  <div class="col-xs-3">
    <label for="song_name">Song ID </label>
    <input type="text" id="song_name" name="song_id" placeholder="Song name..">
   </div>
  <div class="col-xs-3">
    <label for="song_name">Song Name </label>
    <input type="text" id="song_name" name="song_name" placeholder="Song name..">
   </div>
    <div class="col-xs-3">
    <label for="lname">Song Photo </label>
    <input type="file" id="song_photo" name="song_photo" placeholder="song_photo">
      </div>
	  <div class="col-xs-3">
    <label for="song_name">Song Audio </label>
    <input type="file" id="song_photo" name="song_audio" placeholder="song_audio">
   </div>
   </div>
   <div class="row">
   <div class="col-xs-3">
    <label for="song_name">Album Name</label>
    <input type="text" id="song_name" name="song_album" placeholder="Album name..">
	</div>
	</div>
	<div class="row">
	<div class="col-xs-4">
	
    <input type="submit" value="Submit">
	</div>
	</div>
  </form>
</div>
</span></h1>
</body>
</html>
