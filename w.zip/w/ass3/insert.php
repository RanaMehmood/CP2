<?php

require_once("conn.php");

$name = $_POST['name'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$cpass = $_POST['cpass'];

$query="SELECT * FROM `signup` WHERE Email='$email'";
$res = mysqli_query($conn,"$query") or die("Query error". mysql_error());
$row=mysqli_fetch_array($res);




if($name=="" || $email=="" || $pass=="" || $cpass=="" )
{
	header("Location: create.php");
}
else{
	if($row)
{



header("Location: create3.php");

}else
		{
			
			
			
			
				if($cpass == $pass)
				{
				$query="INSERT INTO `signup`(`Name`, `Email`, `Password`, `Cpassword`) VALUES ('$name','$email','$pass','$cpass')";
						$res = mysqli_query($conn,"$query") or die("Query error". mysql_error());
						header("Location: Homelogin.php");
				}
				else
				{
				header("Location: create2.php");
				}
				
				/*if(isset($email)){
					$pattern="[\w-]+@([\w-]+\.)+[\w-]+";
					 if(preg_match($pattern,$email))
					{
					  if($cpass == $pass)
						{
						$query="INSERT INTO `signup`(`Name`, `Email`, `Password`, `Cpassword`) VALUES ('$name','$email','$pass','$cpass')";
								$res = mysqli_query($conn,"$query") or die("Query error". mysql_error());
								header("Location: Homelogin.php");
						}
						else
						{
						header("Location: create2.php");
						}
	                }
	 else{
		 echo" fail";
		 $e="not valid";
		 header("Location: create.php?e=".$e);
	 }
}
		}*/
}
?>




		