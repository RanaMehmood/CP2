<?php

require_once("conn.php");
session_start();
$errors = array(); 
$email = $_POST['email'];
$pass = $_POST['pass'];


$query="SELECT * FROM `signup` WHERE Email='$email' and Password='$pass' ";
$res = mysqli_query($conn,"$query") or die("Query error". mysql_error());
$row=mysqli_fetch_array($res);





if(empty($row))
{
	$e="not valid";
		 header("Location: login.php?e=".$e);
	
}
else
{
$_SESSION["id"]=$row["Email"];

header("Location: Homecreate.php");

}
?>

		
		
		
		
		
		
		