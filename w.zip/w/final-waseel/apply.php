<?php
session_start();
$connection = mysqli_connect('localhost','root','','army_db');
if(!$connection)
    die("'army_db' database not connected.");
else
{
	echo "ok done";
}
/* Question 2:  Write the code below accordingly */
echo  $_SESSION['test']
 
?>
