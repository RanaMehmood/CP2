
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAD-H UCP Assignment 2</title>
	<meta charset="UTF-8">
	<meta name="description" content="UCP Section H Assignment 2">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="M Talha">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="images/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="js/main.js"></script> 
</head>
<body>
<div class="container top">
	<div class="row">
		<div class="col-sm-3"><p>UCP joher town lahore|call us on +9200000 </p></div>
		<div class="col-sm-6"></div>
		<div class="col-sm-3"><p>our teaam|Faq</p></div>
	</div>	
	</div>	
<header class="jumbotron text-center">
<div class="container navi">
		<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		<nav class="navbar navbar-expand-sm navbar-dark">
	<div class="container navi">
		<div class="row">
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item">
				<a class="dropdown-toggle nav-link " data-toggle="dropdown" href="#">Home</a>
			  </li>
			  <li class="nav-item">
				<a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">pages</a>
			  </li>
			  <li class="nav-item">
				<a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">portfolio</a>
			  </li> 
              <li class="nav-item">
				<a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">blogs</a>
			  </li>
				<li class="nav-item">
				<a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">shops</a>
			  </li>
			  <li class="nav-item">
				<a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">element</a>
                
			  </li>
			</ul>
			</div>
		</div>
	</div>
	
</nav>
		</div>
		</div>
		</div>


	<div class="container head">
		<div class="row">
			<h1>HI UCP</h1>
			<h5>Class Activity<h5>
		</div>
	</div>
</header>
<div class="container">
      <div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		<h2>  what I Can Do</h2>
		</div>
		<div class="col-sm-4"></div>
</div>
</div>
<div class="container">
      <div class="row">
		<div class="col-sm-4">
		<h2><small>Fully Responsive</small></h2>
		<h6><small>Responsive websites are the future! They allow your site to adapt to different screen sizes which means that whatever device your .</small></h6>
		</div>
		<div class="col-sm-4">
		<h2><small>Powerfull Portfolios</small></h2>
		<h6><small>The use of portfolio assessment is a valuable tool for teachers to use with young children to better understand how young children develop and lear<small></h6>
		</div>
		
		<div class="col-sm-4">
		<h2><small>Shortcodes</small></h2>
		<h6><small>nothing understand</small></h6>
		</div>
</div>
</div>
<div class="container">
      <div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><h2>A little bit about me</h2></div>
		<div class="col-sm-4"></div>
</div>
</div>
<div class="container">
      <div class="row">
		<div class="col-sm-4"><img src="/ass/images/w.jpg" width="300" height="300"></div>
		<div class="col-sm-8"><h6>I am a student of bscs. my uni name is university of central punjab also, Become a good software engineer and understanding the professional and ethical responsibility</h6></div>
		
</div>
</div>
<div class="container bot">
<div class="container">
      <div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><h2>Say hello</h2></div>
		<div class="col-sm-4"></div>
</div>
</div>
<div class="container">
      <div class="row">
		<div class="col-sm-6">		
		
		<h1 style="color:blue;">Thank you<h1>
		<form name="RegForm" action="" onsubmit="return formvalidatefunc()" method="post">  
			          
		</form> 
		</div>
		
		<div class="col-sm-6"><h4>Contact info</h4>
		<h6 style="color:black;"><small>We help prospective students to explore different options while making decision for their future endeavors.
										The primary function of Admission office is to be of assistance to students in any way possible.</small></h6>
		
		<h6 style="color:black;"><small>UCP Joher town</small></h6>
		<h6 style="color:black;"><small>test@ucp.edu.pk</small></h6>
		<h6 style="color:black;"><small>+92000000000</small></h6>
		
		</div>
		

</div>
</div>
<footer class="jumbotron text-center">
<div class="container">
      <div class="row">
		<div class="col-sm-3">
		<p style="color:white;">About me</p>
		<h6 style="color:black;"><small>BSCS 7th Semester Student</small></h6>
		 <input type="text" placeholder="Search.." name="search">
		</div>
		<div class="col-sm-3">
		<p style="color:white;">Contact with Me</p>
		<h6 style="color:black;"><small>facebook</small></h6>
		<h6 style="color:black;"><small>tweeter</small></h6>
		<h6 style="color:black;"><small>instagram</small></h6>
		</div>
		
		<div class="col-sm-3">
		<p style="color:white;">Additional Link</p>
		<h6 style="color:black;"><small>project</small></h6>
		<h6 style="color:black;"><small>pages</small></h6>
		<h6 style="color:black;"><small>shops</small></h6>
		
		</div>
		<div class="col-sm-3">
		<p style="color:white;">Contact Me</p>
		<h6 style="color:black;"><small>UCP Joher town</small></h6>
		<h6 style="color:black;"><small>test@ucp.edu.pk</small></h6>
		<h6 style="color:black;"><small>+92000000000</small></h6>
		</div>
</div>
</div>	
</footer>
</body>
</html>
